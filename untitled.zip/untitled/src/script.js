const canvas = document.getElementById("tetris");
const ctx = canvas.getContext("2d");
const ROWS = 20;
const COLS = 10;
const BLOCK_SIZE = 30;

canvas.width = COLS * BLOCK_SIZE;
canvas.height = ROWS * BLOCK_SIZE;

const board = Array.from({ length: ROWS }, () => Array(COLS).fill(0));

const tetrominoes = [
    [[1, 1, 1, 1]], // I
    [[1, 1], [1, 1]], // O
    [[0, 1, 0], [1, 1, 1]], // T
    [[1, 1, 0], [0, 1, 1]], // Z
    [[0, 1, 1], [1, 1, 0]], // S
    [[1, 1, 1], [1, 0, 0]], // L
    [[1, 1, 1], [0, 0, 1]]  // J
];

const colors = ["cyan", "yellow", "purple", "red", "green", "orange", "blue"];

let currentTetromino = getRandomTetromino();
let pos = { x: 3, y: 0 };
let dropCounter = 0;
let dropInterval = 1000;
let lastTime = 0;

function getRandomTetromino() {
    const index = Math.floor(Math.random() * tetrominoes.length);
    return {
        shape: tetrominoes[index],
        color: colors[index]
    };
}

function drawBoard() {
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (let y = 0; y < ROWS; y++) {
        for (let x = 0; x < COLS; x++) {
            if (board[y][x]) {
                ctx.fillStyle = board[y][x];
                ctx.fillRect(x * BLOCK_SIZE, y * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
            }
        }
    }
}

function drawTetromino() {
    currentTetromino.shape.forEach((row, y) => {
        row.forEach((cell, x) => {
            if (cell) {
                ctx.fillStyle = currentTetromino.color;
                ctx.fillRect((pos.x + x) * BLOCK_SIZE, (pos.y + y) * BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE);
            }
        });
    });
}

function collide() {
    return currentTetromino.shape.some((row, y) =>
        row.some((cell, x) =>
            cell && (board[pos.y + y]?.[pos.x + x] !== 0 || pos.y + y >= ROWS)
        )
    );
}

function merge() {
    currentTetromino.shape.forEach((row, y) => {
        row.forEach((cell, x) => {
            if (cell) {
                board[pos.y + y][pos.x + x] = currentTetromino.color;
            }
        });
    });
}

function clearLines() {
    for (let y = ROWS - 1; y >= 0; y--) {
        if (board[y].every(cell => cell !== 0)) {
            board.splice(y, 1);
            board.unshift(Array(COLS).fill(0));
        }
    }
}

function drop() {
    pos.y++;
    if (collide()) {
        pos.y--;
        merge();
        clearLines();
        currentTetromino = getRandomTetromino();
        pos = { x: 3, y: 0 };
        if (collide()) {
            alert("Game Over!");
            board.forEach(row => row.fill(0));
        }
    }
}

function move(dir) {
    pos.x += dir;
    if (collide()) pos.x -= dir;
}

function rotate() {
    const rotated = currentTetromino.shape[0].map((_, index) =>
        currentTetromino.shape.map(row => row[index]).reverse()
    );
    const prevShape = currentTetromino.shape;
    currentTetromino.shape = rotated;
    if (collide()) currentTetromino.shape = prevShape;
}

function update(time = 0) {
    const deltaTime = time - lastTime;
    lastTime = time;
    dropCounter += deltaTime;
    if (dropCounter > dropInterval) {
        drop();
        dropCounter = 0;
    }
    drawBoard();
    drawTetromino();
    requestAnimationFrame(update);
}

document.addEventListener("keydown", event => {
    if (event.key === "ArrowLeft") move(-1);
    if (event.key === "ArrowRight") move(1);
    if (event.key === "ArrowDown") drop();
    if (event.key === "ArrowUp") rotate();
});

update();
