import logging
import os
import time
import threading
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from templates import get_template_path, TEMPLATE_INFO
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({"status": "active", "message": "Bot is running!"})

@app.route('/health')
def health():
    return jsonify({"status": "healthy", "timestamp": time.time()})

def run():
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))

def keep_alive():
    server = threading.Thread(target=run)
    server.daemon = True  # This ensures the thread will be stopped when the main program exits
    server.start()

# Configure more detailed logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
    level=logging.DEBUG  # Changed to DEBUG for more detailed logs
)
logger = logging.getLogger(__name__)
logger.info("Bot script started")

# Bot token should be set as environment variable
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "your-token-here")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    keyboard = [
        [InlineKeyboardButton("İcazə ərizəsi", callback_data='icaze')],
        [InlineKeyboardButton("Məzuniyyət ərizəsi", callback_data='mezuniyyet')],
        [InlineKeyboardButton("İstefa ərizəsi", callback_data='istefa')],
        [InlineKeyboardButton("Xasiyyətnamə", callback_data='xasiyyetname')]
    ]

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        'Xoş gəlmisiniz! Zəhmət olmasa, lazım olan sənəd şablonunu seçin:',
        reply_markup=reply_markup
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /help is issued."""
    help_text = """
🔹 Mövcud əmrlər:
/start - Botu başladın
/help - Kömək menyusu
/templates - Mövcud şablonların siyahısı

🔹 Şablon endirmək üçün:
1. /start əmrini göndərin
2. Lazım olan şablonu seçin
3. Şablon avtomatik olaraq göndəriləcək
"""
    await update.message.reply_text(help_text)

async def templates_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """List all available templates."""
    templates_text = "📄 Mövcud şablonlar:\n\n"
    for template_id, info in TEMPLATE_INFO.items():
        templates_text += f"• {info['name']} - {info['description']}\n"

    await update.message.reply_text(templates_text)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button press."""
    query = update.callback_query
    await query.answer()

    template_id = query.data
    if template_id in TEMPLATE_INFO:
        try:
            template_path = get_template_path(template_id)
            with open(template_path, 'rb') as doc:
                await query.message.reply_document(
                    document=doc,
                    filename=TEMPLATE_INFO[template_id]['filename'],
                    caption=f"📄 {TEMPLATE_INFO[template_id]['name']}\n\n{TEMPLATE_INFO[template_id]['description']}"
                )
        except FileNotFoundError as e:
            logger.error(f"Template file not found: {e}")
            await query.message.reply_text(
                "❌ Bağışlayın, şablon faylı tapılmadı. Administratora müraciət edin."
            )
        except Exception as e:
            logger.error(f"Error sending document: {e}")
            await query.message.reply_text(
                "❌ Bağışlayın, şablonu göndərərkən xəta baş verdi. Zəhmət olmasa, bir az sonra yenidən cəhd edin."
            )
    else:
        await query.message.reply_text("❌ Seçilmiş şablon tapılmadı.")

def main() -> None:
    """Start the bot."""
    retry_count = 0
    max_retries = 999999  # Practically infinite retries
    base_delay = 1  # Starting delay in seconds

    # Start the Flask server first
    keep_alive()
    logger.info("Web server started")

    while retry_count < max_retries:
        try:
            logger.info("Starting bot...")
            application = Application.builder().token(TOKEN).build()

            # Add handlers
            application.add_handler(CommandHandler("start", start))
            application.add_handler(CommandHandler("help", help_command))
            application.add_handler(CommandHandler("templates", templates_command))
            application.add_handler(CallbackQueryHandler(button))

            # Run the bot with more aggressive keep-alive settings
            application.run_polling(
                allowed_updates=Update.ALL_TYPES,
                drop_pending_updates=True,
                timeout=60,  # Shorter timeout for faster recovery
                read_timeout=60,
                write_timeout=60,
                pool_timeout=60,
                connect_timeout=60
            )

            # If we get here, the bot is running successfully
            retry_count = 0  # Reset retry count on successful run
            logger.info("Bot is running successfully")

        except Exception as e:
            retry_count += 1
            # More gradual backoff: max 2 minutes instead of 5
            delay = min(120, base_delay * (1.5 ** retry_count))  
            logger.error(f"Error in main function (attempt {retry_count}): {e}")
            logger.info(f"Waiting {delay:.2f} seconds before retry...")
            time.sleep(delay)
            logger.info("Attempting to restart bot...")

    logger.critical("Max retries reached. Bot stopped.")

if __name__ == '__main__':
    main()