import os

# Template information dictionary
TEMPLATE_INFO = {
    'icaze': {
        'name': 'İcazə ərizəsi',
        'description': 'İşdən icazə almaq üçün ərizə şablonu',
        'filename': 'icaze.docx'
    },
    'mezuniyyet': {
        'name': 'Məzuniyyət ərizəsi',
        'description': 'İllik məzuniyyət üçün ərizə şablonu',
        'filename': 'mezuniyyet.docx'
    },
    'istefa': {
        'name': 'İstefa ərizəsi',
        'description': 'İşdən çıxmaq üçün ərizə şablonu',
        'filename': 'istefa.docx'
    },
    'xasiyyetname': {
        'name': 'Xasiyyətnamə',
        'description': 'İş yerindən xasiyyətnamə şablonu',
        'filename': 'xasiyyetname.docx'
    }
}

def get_template_path(template_id: str) -> str:
    """Get the full path for a template file."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    template_path = os.path.join(base_dir, 'templates', TEMPLATE_INFO[template_id]['filename'])
    if not os.path.exists(template_path):
        raise FileNotFoundError(f"Template file not found: {template_path}")
    return template_path